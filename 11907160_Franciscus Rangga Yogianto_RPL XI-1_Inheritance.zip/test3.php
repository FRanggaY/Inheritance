<?php
class produk{
  public $namaLaptop, 
          $merk, 
            $harga,
                $ukuranlayar,
                    $kapasitas;
            public function cetakProduk(){
                return "$this->merk, (Rp $this->harga)";
            }
            public function __construct($namaLaptop="Nama Laptop : ", $merk="Merk : ", $harga = 0, $ukuranlayar="Ukuran Layar", $kapasitas="Kapasitas")
            {
                $this->namaLaptop = $namaLaptop;
                $this->merk = $merk;
                $this->harga = $harga;
                $this->ukuranlayar = $ukuranlayar;
                $this->kapasitas = $kapasitas;
            }
            
        public function cetakInfo(){
            $str="{$this->namaLaptop}, {$this->cetakProduk()}";
            return $str; 
        }        
}

class laptopjenis1 extends produk{
    public function cetakInfo(){
        $str="Laptop A: {$this->namaLaptop}, {$this->cetakProduk()} | Ukuran Layar: {$this->ukuranlayar}";
        return $str; 
    }
}
class laptopjenis2 extends produk{
    public function cetakInfo(){
        $str="Laptop B: {$this->namaLaptop}, {$this->cetakProduk()} | Kapasitas: {$this->kapasitas}";
        return $str; 
    }
}


$produk1 = new laptopjenis1("Predator","Acer",23000000,"14 Inch","-");
$produk2 = new laptopjenis2("ROG Strix","Asus",64000000,"-","8 Gb");

echo $produk1->cetakInfo();
echo "<br>";
echo $produk2->cetakInfo();
echo "<br>";

?>